function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(255, 204, 0);
  fill(255, 0, 0);

  // rect (x, y, witdh, height)
  rect(150, 150, 120, 60);
  fill(0, 255, 0);
  rect(160, 100, 100, 50);
  fill(0, 0, 255);
  rect(170, 60, 80, 40);

  // ellipse (x, y, witdh, height)
  fill(255);
  ellipse(170, 210, 30, 30);
  ellipse(250, 210, 30, 30);

  // triangle (x1, y1, x2, y2, x3, y3)
  //triangle (40, 85, 68, 30, 96, 85);
}
