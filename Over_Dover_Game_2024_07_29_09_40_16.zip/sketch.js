var numFrames = 6;
var frame = 0;
var images = new Array(numFrames);
var platforms = [];
var clouds = [];
var lives = 3;
var score = 0;
var gameState = "start";
var speedIncrement = 0.1;

function preload() {
  for (let i = 0; i < numFrames; i++) {
    images[i] = loadImage("dove" + nf(i + 1, 2) + ".png");
  }
}

function setup() {
  createCanvas(600, 400);
  frameRate(15);

  //blocks/platforms
  for (let i = 0; i < 5; i++) {
    let x = random(-width, 0);
    let y = random(height);
    let w = random(50, 100);
    let h = 20;
    let speed = random(6, 10);
    platforms.push(new Platform(x, y, w, h, speed));
  }

  //clouds
  for (let i = 0; i < 10; i++) {
    clouds.push(new Cloud(random(width), random(height / 2)));
  }
}

//blue sky
function draw() {
  background(135, 206, 235);

  //for cloud shape
  for (let cloud of clouds) {
    cloud.update();
    cloud.display();
  }

  if (gameState === "start") {
    showStartScreen();
  } else if (gameState === "playing") {
    for (let platform of platforms) {
      platform.update();
      platform.display();

      if (platform.hits(mouseX, mouseY)) {
        lives--;
        if (lives <= 0) {
          gameState = "gameover";
        }
      }
    }

    //dove
    image(images[frame], mouseX - 75, mouseY - 100);
    frame = (frame + 1) % numFrames;

    //lives and scores display
    fill(0);
    textSize(20);
    text("Lives: " + lives, 20, 30);
    text("Score: " + score, 20, 60);

    //increase speed
    if (frameCount % 120 === 0) {
      speedIncrement += 0.1;
    }
  } else if (gameState === "gameover") {
    showGameOverScreen();
  }
}

class Platform {
  constructor(x, y, width, height, speed) {
    this.x = x;
    this.y = y;
    this.width = width;
    this.height = height;
    this.speed = speed;
  }

  update() {
    this.x += this.speed + speedIncrement;

    if (this.x > width) {
      this.x = -this.width;
      this.y = random(height);
      this.width = random(50, 100);
      this.speed = random(6, 10);
      score++;
    }
  }

  display() {
    fill(0);
    rect(this.x, this.y, this.width, this.height);
  }

  hits(doveX, doveY) {
    return (
      doveX > this.x &&
      doveX < this.x + this.width &&
      doveY > this.y &&
      doveY < this.y + this.height
    );
  }
}

class Cloud {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = random(50, 100);
    this.speed = random(1, 3);
  }

  update() {
    this.x += this.speed;
    if (this.x > width) {
      this.x = -this.size;
      this.y = random(height / 2);
    }
  }

  display() {
    fill(255);
    noStroke();
    ellipse(this.x, this.y, this.size, this.size / 2);
    ellipse(this.x + 20, this.y - 10, this.size / 1.5, this.size / 2.5);
    ellipse(this.x - 20, this.y - 10, this.size / 1.5, this.size / 2.5);
  }
}

function showStartScreen() {
  textAlign(CENTER);
  textSize(32);
  fill(0);
  text("Click to Start", width / 2, height / 2);
}

function showGameOverScreen() {
  textAlign(CENTER);
  textSize(32);
  fill(0);
  text("Game Over", width / 2, height / 2);
  text("Click to Restart", width / 2, height / 2 + 40);
}

function mousePressed() {
  if (gameState === "start" || gameState === "gameover") {
    restartGame();
    gameState = "playing";
  }
}

function restartGame() {
  lives = 3;
  score = 0;
  speedIncrement = 0.1;
  platforms = [];
  for (let i = 0; i < 5; i++) {
    platforms.push(
      new Platform(
        random(-width, 0),
        random(height),
        random(50, 100),
        20,
        random(6, 10)
      )
    );
  }
}
