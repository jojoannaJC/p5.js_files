function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255, 0, 75);
  fill(0, 255, 0);
  ellipse(210,170,300,300);
  fill(255);
  circle(150, 150, 100, 100);
  fill(0);
  ellipse(150, 150, 30, 50);
  fill(255);
  circle(270, 150, 100, 100);
  fill(0);
  ellipse(270, 150, 30, 50);
}