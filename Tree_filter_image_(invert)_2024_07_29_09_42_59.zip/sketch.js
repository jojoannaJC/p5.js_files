var img;

function preload() {
 img = loadImage("tree.jpg");
}

function setup() {
  createCanvas(400, 400);
  background(0);
}

function draw() {
  background(0);
  image(img, 0, 0);
  filter(INVERT);
  var v = map(0, mouseY, width, 5, 0);
  //filter(BLUR, v);
  //filter(POSTERIZE, v)
}